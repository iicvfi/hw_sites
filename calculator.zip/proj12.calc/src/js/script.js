let nominals=[
    1,
    1.1,
    1.2,
    1.3,
    1.5,
    1.6,
    1.8,
    2,
    2.2,
    2.4,
    2.7,
    3,
    3.3,
    3.6,
    3.9,
    4.3,
    4.7,
    5.1,
    5.6,
    6.2,
    6.8,
    7.5,
    8.2,
    9.1,
    ];

let nominalsCol=[
[1,0],
[1,1],
[1,2],
[1,3],
[1,5],
[1,6],
[1,8],
[2,0],
[2,2],
[2,4],
[2,7],
[3,0],
[3,3],
[3,6],
[3,9],
[4,3],
[4,7],
[5,1],
[5,6],
[6,2],
[6,8],
[7,5],
[8,2],
[9,1],
];

let butt1= document.querySelector('.butt1');

let arrL =[
   [0.02, 1.9],
   [0.02, 2.3],
   [0.02, 2.1],
   [0.02, 3],
];




let colors=[
'black',
'brown',
'red',
'orange',
'yellow',
'green',
'blue',
'purple',
'grey',
'white',
'gold',
];



let rez;
let rez1;
let kfl=0;
function calculateD(){

    let num1 = Number(document.getElementById("num1").value);
    let position = document.querySelector('.led');
    
    

   
     rez= (num1 - arrL[position.value-1][1])/arrL[position.value-1][0];// значение сопротивления 
     rez1 = rez;

        if(rez<1000){
            kfl=0;
            document.getElementById("res").innerHTML = rez1 +" Ом";
        }

        else{
            kfl=1;
            rez1/=1000;
            document.getElementById("res").innerHTML = rez1 +" кОм";
        }

    

}

let RezInd;
let ind;

function calculateN() {

    let rez2;
    let rez3;
    let diff=10;
    



    if(rez1<10){

        rez2= rez1;
        ind=1;

    }
    if(rez1<100 && rez1>=10){

        rez2= rez1/10;
        ind=2;
    }

    if(rez1<1000 && rez1>=100){
        rez2= rez1/100;
        ind=3;
    }

    console.log(rez2);

if(rez2>nominals[23]){
    RezInd=0;
    rez2=1;
    ind++;
   if(rez1>910){
       ind=1;
       kfl=1;
   }
}


else{
    nominals.forEach((item,i)=>{

        if(Math.abs(nominals[i]-rez2)<diff){
     
         diff= Math.abs(nominals[i]-rez2);
     
     if(nominals[i]>=rez2){
         console.log(diff);
         RezInd= i;
     
     }
     else{
         console.log(diff);
         RezInd= i+1;
     }
     
         
        }
     
         });
}

    

   console.log(RezInd);

        switch(ind){

            case 1:

                rez2= nominals[RezInd];

            break;

            case 2:
                rez2= nominals[RezInd]*10;
            break;

            case 3:
                rez2= nominals[RezInd]*100;
            break;

        }


        if(kfl===0){

            rez3 = Math.round(rez2 * Math.pow(10, 1)) / Math.pow(10, 1);

        document.getElementById("resN").innerHTML = rez3 +" Ом";

           
        }

        if(kfl===1){

            rez3= Math.round(rez2 * Math.pow(10, 1)) / Math.pow(10, 1);

        document.getElementById("resN").innerHTML = rez3 +" кОм";

        }
       
}

let stripes = document.querySelectorAll('.box_resistor');

function ResPrint(){


stripes[3].style.backgroundColor= 'gold';
stripes[3].style.width= '4px';
let ctCol =[
0,0,0,
];

ctCol[0]= nominalsCol[RezInd][0];
ctCol[1]= nominalsCol[RezInd][1];

switch(ind){

    case 1:

    if(kfl===0){

        ctCol[2]=10;
    } else{

        ctCol[2]=2;


    }
    
    break;

    case 2:
        if(kfl===0){

            ctCol[2]=0;
        } else{
    
            ctCol[2]=3;
    
        }

    break;

    case 3:
        if(kfl===0){

            ctCol[2]=1;
        } else{
    
            ctCol[2]=4;
    
        }
    break;

}


stripes[0].style.backgroundColor= colors[ctCol[0]];
stripes[1].style.backgroundColor= colors[ctCol[1]];
stripes[2].style.backgroundColor= colors[ctCol[2]];




}




butt1.addEventListener('click',()=>{ 
    calculateD();
    calculateN();
    ResPrint();

});


